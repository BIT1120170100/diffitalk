#include "include/chatWindow.h"

#include <gtk/gtk.h>

/**************************************************/
/*名称： 
/*描述：主界面函数，定义主调函数，初始化函数等功能主函数
/*作成日期：  
/*参数： 
/*返回值： 
/*作者： 
/***************************************************/

int main(int argc, char *argv[])
{
        //init
        
        createChatWindow( argc, argv);
        return 0;
}